﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Dominio.DominioServicios.Clases
{
    public class CalcularGastoEmpresa
    {
        public decimal sumaGastos()
        {
            return 1000;
        }
    }
}
