﻿using Plagas.Dominio.DominioServicios.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Dominio.DominioServicios.Clases
{
    public class CalculaGastoJefe : ICalculaGastoJefe
    {
        public decimal CalcularGastoJefe()
        {
            return 10;
        }
    }
}
