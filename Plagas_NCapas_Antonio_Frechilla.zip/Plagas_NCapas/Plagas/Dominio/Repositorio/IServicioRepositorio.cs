﻿using Plagas.Dominio.DominioEntidades;
using System.Collections.Generic;
using System.Threading.Tasks;
using Plagas.Dominio.DominioEntidades.Clases;
using Plagas.Dominio.DominioEntidades.Interfaces;

namespace Plagas.Dominio.RepositoryInterfaces
{
    public interface IServiciosRepositorio
    {
        List<Servicio> Servi();
       
        List<Cliente> Clientes();
        bool GuardaServicios(List<Servicio> Servicios);
        Task<bool> GuardaClientes(List<Cliente> clientes);
        
    }
}
