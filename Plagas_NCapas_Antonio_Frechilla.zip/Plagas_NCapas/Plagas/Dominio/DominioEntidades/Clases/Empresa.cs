﻿using Plagas.Dominio.DominioEntidades.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Dominio.DominioEntidades.Clases
{
    class Empresa : IEmpresa
    {
        public string nombreEmpresa { get; set; }

        public string asignarNombre()
        {
            nombreEmpresa = "Empresa de plagas";
            return nombreEmpresa;
        }

        public decimal CosteEmpresa()
        {
            throw new NotImplementedException();
        }
    }
}
