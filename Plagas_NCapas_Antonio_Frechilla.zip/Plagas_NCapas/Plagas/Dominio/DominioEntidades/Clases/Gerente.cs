﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Plagas.Dominio.DominioEntidades.Interfaces;
using Plagas.Dominio.DominioEntidades.Clases;

namespace Plagas.Dominio.DominioEntidades.Clases
{
   public  class Gerente :  IGerente
    {
        public string rol { get; set; }
        public decimal sueldo { get; set; }
      
        
    }
}
