﻿using Plagas.Dominio.DominioEntidades.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Dominio.DominioEntidades.Clases
{
    public class Cliente  : ICliente
    {
        public int idCliente { get; set; }
        public string nombreCliente { get; set; }
        public string telefono { get; set; }
        public string email { get; set; }
        public string CP { get; set; }

        ICliente ICliente.Cliente()
        {
            throw new NotImplementedException();
        }
    }
}
