﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Dominio.DominioEntidades.Clases
{
    public  class Veneno : Interfaces.IVeneno
    {
        public int idVeneno {  get; set; }
        public string nombre {  get; set; }
        public string unidadDeMedida {  get; set; }

        public decimal costeGramoVeneno { get; set; }
    
    }
}
