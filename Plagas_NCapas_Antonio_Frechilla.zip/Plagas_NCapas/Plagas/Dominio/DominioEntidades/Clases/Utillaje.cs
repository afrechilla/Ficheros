﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Dominio.DominioEntidades.Clases
{
   public  class Utillaje : Interfaces.IUtillaje
    {
        public int idUtillaje { get; set; }
        public string descripcionUtillaje { get; set; }

        public decimal costeUtillaje { get; set; }
   

    }
}
