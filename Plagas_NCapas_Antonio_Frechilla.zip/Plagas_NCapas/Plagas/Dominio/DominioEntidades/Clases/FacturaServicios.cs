﻿using Plagas.Dominio.DominioEntidades.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Dominio.DominioEntidades.Clases
{
    class FacturaServicios : IFacturaServicios
    {
        public int IdFactura { get; set; }
        public int FechaFactura { get; set; }
    }
}
