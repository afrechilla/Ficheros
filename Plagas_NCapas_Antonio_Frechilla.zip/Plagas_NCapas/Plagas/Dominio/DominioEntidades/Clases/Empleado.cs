﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Plagas.Dominio.DominioEntidades.Interfaces;
//using Plagas.Modelo.Interfaces;

namespace Plagas.Dominio.DominioEntidades.Clases
{
   public  class Empleado : IEmpleado
    {
        public int idEmpleado { get; set; }

        public decimal ingresoPorServicio { get; set; }

        public string rol { get; set; }
        
        
    }
}
