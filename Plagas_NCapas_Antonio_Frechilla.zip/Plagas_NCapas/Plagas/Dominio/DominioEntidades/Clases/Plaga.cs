﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Modelo.Objetos
{
    public class Plaga : Interfaces.IPlaga
    {
        public int idPlaga { get; set; }
        public string nombrePlaga { get; set; }
    }
}
