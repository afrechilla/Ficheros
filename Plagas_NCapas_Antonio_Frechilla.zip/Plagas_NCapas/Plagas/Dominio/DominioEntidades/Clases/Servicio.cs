﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Plagas.Dominio.DominioEntidades.Interfaces;
using Plagas.Modelo.Clases;
using Plagas.Modelo.Interfaces;
 

namespace Plagas.Dominio.DominioEntidades.Clases
{
    public class Servicio : IServicio
    {
        RestoFactory resto = new RestoFactory();
        public int idServicio { get; set; }
        public decimal precio { get; set; }

        public Cliente cliente { get; set; }
     

        public Empleado jefeEquipo { get; set; }
        

        public List<Empleado> peones { get; set; }
       

        public List<Utillaje> utillaje { get; set; }
        
        public Veneno veneno { get; set; }

    
    }
}
