﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Dominio.DominioEntidades.Interfaces
{
    public interface ICliente
    {
        int idCliente { get; set; }
        string nombreCliente { get; set; }
        string telefono { get; set; }
        string email { get; set; }
        string CP { get; set; }
        ICliente Cliente();
    }
}
