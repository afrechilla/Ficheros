﻿using Plagas.Dominio.DominioEntidades.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Plagas.Dominio.DominioEntidades.Clases;

namespace Plagas.Dominio.DominioEntidades.Interfaces
{
    public interface IServicio  
    {
        int idServicio { get; set; }
        decimal precio { get; set; }

        Cliente cliente { get; set; }
        Empleado jefeEquipo { get; set; }
        Veneno veneno { get; set; }
        List<Empleado> peones { get; set; }
        List<Utillaje> utillaje { get; set; }

        //List<IPeon> damePeones(List<IPeon> listaPeones);
    }
}
