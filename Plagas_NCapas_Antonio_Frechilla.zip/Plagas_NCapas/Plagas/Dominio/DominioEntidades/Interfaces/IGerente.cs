﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Dominio.DominioEntidades.Interfaces
{
    public interface IGerente 
    {
        string rol { get; set; }
        decimal sueldo { get; set; }

    }
}
