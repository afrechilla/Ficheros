﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Dominio.DominioEntidades.Interfaces
{
   public interface IFacturaServicios
    {
        int IdFactura { get; set; }
        int FechaFactura { get; set;  }
    }
}
