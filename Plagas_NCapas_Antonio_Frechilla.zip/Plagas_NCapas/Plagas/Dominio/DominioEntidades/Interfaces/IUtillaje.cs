﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Dominio.DominioEntidades.Interfaces
{
    public interface IUtillaje
    {
        int idUtillaje { get; set; }
        string descripcionUtillaje { get; set; }
        decimal costeUtillaje { get; set; }

    }
}
