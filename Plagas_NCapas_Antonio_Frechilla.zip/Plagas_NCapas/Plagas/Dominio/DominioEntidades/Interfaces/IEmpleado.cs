﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Dominio.DominioEntidades.Interfaces
{
    public interface IEmpleado
    {
        int idEmpleado { get; set; }
        decimal ingresoPorServicio { get; set; }
        string rol { get; set; }


    }
}
