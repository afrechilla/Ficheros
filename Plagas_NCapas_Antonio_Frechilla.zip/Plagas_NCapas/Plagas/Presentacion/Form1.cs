﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Autofac;
using Plagas.Dominio.DominioEntidades.Clases;
using Plagas.Dominio.DominioEntidades.Interfaces;
using Plagas.Modelo.Clases;
using System.Configuration;
using Plagas.Modelo.Clases;
using Plagas.Modelo.Interfaces;
using System.Reflection;

namespace Plagas
{
    public partial class Form1 : Form
    {
        public IClienteFactory cf;
        public List<ICliente> ListaClientes = new List<ICliente>();
        public IEmpresa EmpresaActual;
        private static Autofac.IContainer  Container { get; set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCrearEmpresa_Click(object sender, EventArgs e)
        {
            // ejecutamos solo una vez 
           // grabarConfiguraciones();

            // Ejecutamos siempre 
            DeleteEmpresa();

             EmpresaActual = BuilderEmpresa();

        }

        private void DeleteEmpresa()
        {// 
            EmpresaActual = null;
            // aqui se pondrían todos los objetos creados
        }
        
        public IEmpresa BuilderEmpresa()
        {

            ContainerBuilder builderEmpresa = new ContainerBuilder();
            builderEmpresa.RegisterType<Empresa>().As<IEmpresa>();
            Container = builderEmpresa.Build();
            ILifetimeScope scope = Container.BeginLifetimeScope();
            IEmpresa empresaCreada = scope.Resolve<IEmpresa>();

            // Establecer valores a partir de la configuracion
            
            System.Configuration.Configuration config =
                ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            System.Configuration.AppSettingsSection appSettings = config.AppSettings;
            string _nombreEmpresa = "";
            if (appSettings.Settings.Count != 0)
            {
                _nombreEmpresa = appSettings.Settings["NombreEmpresa"].Value;
            }

                empresaCreada.nombreEmpresa = _nombreEmpresa;
            return empresaCreada;
        }

        public void grabarConfiguraciones()
        {   // Sólo se ejecuta una vez, las configuraciones se cambian manualmente editando
            // el archivo: Plagas_NCapas\Plagas\bin\Debug\Plagas.exe.Config.xml
            System.Configuration.Configuration config =
                ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            System.Configuration.AppSettingsSection appSettings = config.AppSettings;
            // Crear una clave setting
            string keyName = "NombreEmpresa"  ;
            string value = "Empresa de Plagas";
            appSettings.Settings.Add(keyName, value);
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

        }

        private void btnAddCliente_Click(object sender, EventArgs e)
        {
            cf = new ClienteFactory();
            
            ListaClientes.Add(cf.CreateInstance(Convert.ToInt32(txtIdCliente.Text),
                txtNombreCliente.Text.ToString(), txtTelefono.Text.ToString(),
                txtEmail.Text.ToString(), txtCP.Text.ToString()) );
            btnListarClientes_Click( sender,  e);

        }

        private void btnListarClientes_Click(object sender, EventArgs e)
        {
            DataTable table = CrearDataTable();
            MostrarDatatable(table);
        }

        private DataTable CrearDataTable()
        {
            // Create new DataTable and DataSource objects.
            DataTable table = new DataTable();
            // Declare DataColumn and DataRow variables.
            DataColumn column;
            DataRow row;
            DataView view;

            PropertyInfo[] props = typeof(Cliente).GetProperties(BindingFlags.Public | BindingFlags.Instance);



            // Add the properties as columns to the datatable
            foreach (var prop in props)
            {
                Type propType = prop.PropertyType;

                // Is it a nullable type? Get the underlying type 
                if (propType.IsGenericType && propType.GetGenericTypeDefinition().Equals(typeof(Nullable<>)))
                    propType = new NullableConverter(propType).UnderlyingType;

                table.Columns.Add(prop.Name, propType);
            }

            var listaRegistros = from p in ListaClientes    // Lista de pedidos
                                      select p;

            // IEnumerable<Diccionario> myList = (IEnumerable<Diccionario>)listaPedidosLineas2.ToList();

           
            foreach (var lista in listaRegistros)
            {
                row = table.NewRow();
                //int i = 0;
                //foreach (var prop in props)
                //{
                //    var valorCampo =  prop.GetValue(prop,null);

                //    row[i] = valorCampo;
                //        i++;
                //}

                //  List<CPropiedadValor> lPropiedadValor = new List<CPropiedadValor>();

                 //foreach (PropertyInfo propiedad in lista.GetType().GetProperties())
                //{
                //    CPropiedadValor oPropiedadValor = new CPropiedadValor();
                //    oPropiedadValor.Propiedad = SepararPalabras(propiedad.Name);
                //    oPropiedadValor.Valor = propiedad.GetValue(objeto).ToString();

                //    lPropiedadValor.Add(oPropiedadValor);
                //}

                row[0] = lista.idCliente;
                row[1] = lista.nombreCliente;
                row[2] = lista.telefono;
                row[3] = lista.email;
                row[4] = lista.CP;

                table.Rows.Add(row);
            }
            return table;
        }//   private DataTable CrearDataTable()

        public void MostrarDatatable(DataTable table)
        {
            // Create a DataView using the DataTable.
            DataView view = new DataView(table);

            // Set a DataGrid control's DataSource to the DataView.
            dataGridView1.DataSource = view;
        }

        private void btnCrearRecursos_Click(object sender, EventArgs e)
        {
           RestoFactory resto = new RestoFactory();
           Gerente  gerente = resto.crearGerente();
           Veneno veneno = resto.crearVeneno();
           Empleado jefe = resto.crearJefe();
           List<Empleado> peones = resto.crearPeones();
           RestoFactory servicio = new RestoFactory();
           Servicio S =  servicio.crearServicio();
        }
    }
}
