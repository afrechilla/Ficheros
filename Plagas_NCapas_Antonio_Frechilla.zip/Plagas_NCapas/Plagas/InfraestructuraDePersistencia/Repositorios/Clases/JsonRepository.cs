﻿using Newtonsoft.Json;
using Plagas.Aplicacion;
using Plagas.Dominio.DominioEntidades;
using Plagas.Dominio.DominioEntidades.Clases;
using Plagas.Dominio.DominioEntidades.Interfaces;
using Plagas.Dominio.RepositoryInterfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Plagas.InfraestructuraDePersistencia.Repositorios.Clases
{
    class JsonRepository : IServiciosRepositorio
    {
   
        private List<Servicio> Servicio;

        public List<Cliente> Clientes()
        {
            throw new System.NotImplementedException();
        }

        public Task<bool> GuardaClientes(List<Cliente> clientes)
        {
            throw new System.NotImplementedException();
        }

        public bool GuardaServicios(List<Servicio> Servicios)
        {
            throw new System.NotImplementedException();
        }

         public List<Servicio> Servicios()
        {
            throw new System.NotImplementedException();
        }

        List<Servicio> IServiciosRepositorio.Servi()
        {
            throw new System.NotImplementedException();
        }
    }
}
