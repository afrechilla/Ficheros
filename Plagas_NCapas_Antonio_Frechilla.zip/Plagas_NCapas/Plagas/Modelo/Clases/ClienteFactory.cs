﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Plagas.Dominio.DominioEntidades.Clases;
using Plagas.Dominio.DominioEntidades.Interfaces;
using Plagas.Modelo.Clases;
using Plagas.Modelo.Interfaces;

namespace Plagas.Modelo.Clases
{
    class ClienteFactory : IClienteFactory
    {
             
        public ICliente CreateInstance(int idCliente, 
            string nombreCliente, string telefono, string email, string CP)
        {
            Cliente cliente = new Cliente();
            {
                cliente.idCliente = idCliente;
                cliente.nombreCliente = nombreCliente;
                cliente.telefono = telefono;
                cliente.email = email;
                cliente.CP = CP;
            }
            return cliente;
        }
    }// class ClienteFactory : IClienteFactory
  
}//namespace Plagas.Modelo.Interfaces
