﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Plagas.Dominio.DominioEntidades.Clases;
using Plagas.Dominio.DominioEntidades.Interfaces;

namespace Plagas.Modelo.Clases
{
    public class RestoFactory
    {
        public Cliente crearCliente()
        {
            Cliente cliente = new Cliente();
            cliente.idCliente = 101;
            cliente.nombreCliente = "Cliente 101";
            cliente.telefono = "976101101";
            cliente.email = "cliente101@gmail.com";
            cliente.CP = "50101";
            return cliente;

        }
        public Gerente crearGerente()
        {
            Gerente gerente = new Gerente();
            gerente.rol = "Gerente";
            gerente.sueldo = 40000.5m;

            return gerente;
        }

        public Veneno crearVeneno()
        {
            Veneno veneno = new Veneno();
            veneno.idVeneno = 1;
            veneno.nombre = "Inserticida bloom";
            veneno.unidadDeMedida = "gramo";
            veneno.costeGramoVeneno=0.3m;
            return veneno;
        }

        public Empleado crearJefe()
        {
            Empleado jefe = new Empleado();
            jefe.idEmpleado = 1;
            jefe.ingresoPorServicio = 30;
            jefe.rol = "Jefe de Equipo";
            return jefe;
        }

        public List<Empleado> crearPeones()
        {
            List<Empleado> equipo = new List<Empleado>();

            Empleado empleado2 = new Empleado();
            empleado2.idEmpleado = 2;
            empleado2.ingresoPorServicio = 25;
            empleado2.rol = "Peon";
            equipo.Add(empleado2);

            Empleado empleado3 = new Empleado();
            empleado3.idEmpleado = 3;
            empleado3.ingresoPorServicio = 25;
            empleado3.rol = "Peon";
            equipo.Add(empleado3);

            return equipo;

        }

        public List<Utillaje> crearUtillaje()
        {
            List<Utillaje> listaUtillaje = new List<Utillaje>();
            Utillaje util1 = new Utillaje();
            util1.idUtillaje = 1;
            util1.descripcionUtillaje = "Guantes";
            util1.costeUtillaje = 10m;
            listaUtillaje.Add(util1);

            Utillaje util2 = new Utillaje();
            util2.idUtillaje = 2;
            util2.descripcionUtillaje = "Aplicador";
            util2.costeUtillaje = 30m;
            listaUtillaje.Add(util2);

            return listaUtillaje;
        }

        public Servicio crearServicio()
        {
            Servicio servicio = new Servicio();
            servicio.idServicio = 1;
            servicio.cliente = this.crearCliente();
            servicio.precio = 270.25m;

            servicio.cliente = crearCliente();
            servicio.jefeEquipo = crearJefe();
            servicio.peones = crearPeones();
            servicio.utillaje = crearUtillaje();
            return servicio;
        }
    }
}
