﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Plagas.Dominio.DominioEntidades.Interfaces;

namespace Plagas.Modelo.Interfaces
{
    public interface IClienteFactory
    {
        ICliente CreateInstance(int idCliente, 
            string nombreCliente,string telefono, string email, string CP);
    }
}
