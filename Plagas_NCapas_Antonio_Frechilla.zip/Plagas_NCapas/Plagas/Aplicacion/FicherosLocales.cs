﻿using Plagas.Infraestructura_Transversal.Excepciones;
using Plagas.Infraestructura_Transversal.Log;
using Plagas.Aplicacion;
 


using System;
using System.Threading.Tasks;

namespace Plagas.Aplicacion
{
    public static class FicherosLocales
    {
        private static readonly ILog log = new LogBasico();
        private static System.IO.IsolatedStorage.IsolatedStorageFile local =
                System.IO.IsolatedStorage.IsolatedStorageFile.GetUserStoreForApplication();

        private static string RutaCompleta(string directorio, string nombreFichero)
        {
            return string.Format("{0}\\{1}", directorio, nombreFichero);
        }
        public static async Task<bool> SaveFile(string directorio, string nombreFichero, string data)
        {
            bool exito = true;
            try
            {
                if (!local.DirectoryExists(directorio))
                    local.CreateDirectory(nombreFichero);

                var isoFileStream = new System.IO.IsolatedStorage.IsolatedStorageFileStream(
                            RutaCompleta(directorio, nombreFichero), System.IO.FileMode.Create, System.IO.FileAccess.Write, System.IO.FileShare.None,
                            local);

                using (var isoFileWriter = new System.IO.StreamWriter(isoFileStream))
                {
                    await isoFileWriter.WriteAsync(data);
                }
            }
            catch(Exception ex)
            {
                log.GrabaLog($"se ha lanzado una excepción del tipo Application Exception en el nombre de fichero {nombreFichero} ");
                throw new AplicacionException($"Error en la grabación del fichero: {nombreFichero}", ex);
            }
            return exito;
        }

        public static async Task<string> LoadFile(string directorio, string nombreFichero)
        {

            var isoFileStream = new System.IO.IsolatedStorage.IsolatedStorageFileStream
                        (RutaCompleta(directorio,nombreFichero),
                        System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.None,
                        local);
            
            using (var isoFileReader = new System.IO.StreamReader(isoFileStream))
            {
               return await isoFileReader.ReadToEndAsync();
            }

        }
    }
}
