﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Infraestructura_Transversal.Excepciones
{
    public class ServiciosDistribuidosException : Exception
    {
        protected ServiciosDistribuidosException() { }
        protected ServiciosDistribuidosException(string message) : base(message) { }
        protected ServiciosDistribuidosException(string message, Exception inner) : base(message, inner) { }
    }
}

