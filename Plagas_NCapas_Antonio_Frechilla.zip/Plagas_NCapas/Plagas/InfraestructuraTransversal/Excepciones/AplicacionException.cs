﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Infraestructura_Transversal.Excepciones
{
    public class AplicacionException : Exception
    {
        public AplicacionException() { }
        public AplicacionException(string message) : base(message) { }
        public AplicacionException(string message, Exception inner) : base(message, inner) { }
    }
}
