﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Infraestructura_Transversal.Excepciones
{
    public class PresentacionException : Exception
    {
        protected PresentacionException() { }
        protected PresentacionException(string message) : base(message) { }
        protected PresentacionException(string message, Exception inner) : base(message, inner) { }
    }
}