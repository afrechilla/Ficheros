﻿using System;

namespace Plagas.Infraestructura_Transversal.Excepciones
{
    public abstract class DominioException : Exception
    {
        protected DominioException() { }
        protected DominioException(string message) : base(message) { }
        protected DominioException(string message, Exception inner) : base(message, inner) { }


    }
}
