﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Infraestructura_Transversal.Excepciones
{
    class InfraestructuraDePersistenciaException : Exception
    {
        protected InfraestructuraDePersistenciaException() { }
        protected InfraestructuraDePersistenciaException(string message) : base(message) { }
        protected InfraestructuraDePersistenciaException(string message, Exception inner) : base(message, inner) { }


    }
}
