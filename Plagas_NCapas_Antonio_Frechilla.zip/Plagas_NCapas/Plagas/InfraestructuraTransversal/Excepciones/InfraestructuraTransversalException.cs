﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Infraestructura_Transversal.Excepciones
{
    public class InfraestructuraTransversalException : Exception
    {
        protected InfraestructuraTransversalException() { }
        protected InfraestructuraTransversalException(string message) : base(message) { }
        protected InfraestructuraTransversalException(string message, Exception inner) : base(message, inner) { }


    }
}
