﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Infraestructura_Transversal.Log
{
    public class LogBasico : ILog
    {
        public void GrabaLog(string log)
        {
            throw new NotImplementedException();
        }
    }
}
