﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plagas.Infraestructura_Transversal.Log
{
    public interface ILog
    {
        void GrabaLog(string log);
    }
}
