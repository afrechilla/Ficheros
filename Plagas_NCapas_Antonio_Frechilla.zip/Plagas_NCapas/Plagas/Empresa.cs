﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Plagas.Dominio.DominioEntidades.Interfaces;
using Plagas.Dominio.DominioServicios.Clases;

namespace Plagas
{
    public class Empresa : IEmpresa
    {
        string IEmpresa.nombreEmpresa { get; set; }

        decimal IEmpresa.CosteEmpresa()
        {
            CalcularGastoEmpresa c = new CalcularGastoEmpresa();
            return c.sumaGastos();
        }
    }
}